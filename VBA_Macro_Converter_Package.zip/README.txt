# VBA Macro Converter (32-bit to 64-bit)

## 📦 What’s Inside
- `vba_macro_converter_gui.py` – The full GUI script
- `sample_macro.bas` – Sample macro file to test
- `README.txt` – You’re reading it

## 🖥 Requirements
- Python 3.8 or above
- No additional packages needed (tkinter comes built-in)

## 🚀 How to Run
1. Double-click the Python file (or open terminal and run):
   python vba_macro_converter_gui.py

2. Follow the steps in the GUI:
   - Step 1: Select file/folder containing `.bas` or `.cls`
   - Step 2: Select output folder
   - Step 3: Click “Convert Macros”

3. View results and warnings in the GUI.

## 🧩 Optional: Create EXE
To make a standalone `.exe`:
pip install pyinstaller
pyinstaller --onefile --windowed vba_macro_converter_gui.py
