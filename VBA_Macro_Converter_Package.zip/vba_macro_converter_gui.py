
# vba_macro_converter_gui.py (simplified for ease of use)
import os
import re
from difflib import unified_diff
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

class VBAMacroConverterGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Easy Macro Converter (32-bit to 64-bit)")
        self.tlb_warnings = {}
        self.logs = []
        self.create_widgets()
        self.root.mainloop()

    def create_widgets(self):
        ttk.Label(self.root, text="Step 1: Select VBA macro file or folder").grid(row=0, column=0, columnspan=2, pady=(10, 0))
        ttk.Button(self.root, text="Select File", command=self.select_file).grid(row=1, column=0, padx=10, pady=5)
        ttk.Button(self.root, text="Select Folder", command=self.select_folder).grid(row=1, column=1, padx=10, pady=5)

        ttk.Label(self.root, text="Step 2: Choose where to save converted macros").grid(row=2, column=0, columnspan=2, pady=(10, 0))
        ttk.Button(self.root, text="Select Output Folder", command=self.select_output_folder).grid(row=3, column=0, columnspan=2, pady=5)

        ttk.Label(self.root, text="Step 3: Press Convert to Start").grid(row=4, column=0, columnspan=2, pady=(10, 0))
        ttk.Button(self.root, text="Convert Macros", command=self.convert).grid(row=5, column=0, columnspan=2, pady=10)

        ttk.Label(self.root, text="Warnings or Suggestions:").grid(row=6, column=0, columnspan=2)
        self.warning_text = tk.Text(self.root, width=90, height=8, fg="red")
        self.warning_text.grid(row=7, column=0, columnspan=2, padx=10, pady=5)

        ttk.Label(self.root, text="Conversion Log:").grid(row=8, column=0, columnspan=2)
        self.log_text = tk.Text(self.root, width=90, height=10, fg="blue")
        self.log_text.grid(row=9, column=0, columnspan=2, padx=10, pady=5)

        self.input_paths = []
        self.output_dir = "converted_macros"
        os.makedirs(self.output_dir, exist_ok=True)

    def select_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("VBA Files", "*.bas *.cls")])
        if file_path:
            self.input_paths = [file_path]

    def select_folder(self):
        folder_path = filedialog.askdirectory()
        if folder_path:
            self.input_paths = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(('.bas', '.cls'))]

    def select_output_folder(self):
        self.output_dir = filedialog.askdirectory()
        os.makedirs(self.output_dir, exist_ok=True)

    def read_macro(self, path):
        with open(path, 'r', encoding='utf-8') as file:
            return file.read()

    def write_macro(self, code, output_path):
        with open(output_path, 'w', encoding='utf-8') as file:
            file.write(code)

    def log_tlb_warning(self, filename, libs):
        self.tlb_warnings[filename] = libs

    def convert_code(self, code, filename):
        updated = re.sub(r'(Declare\s+(Sub|Function)\s+.*?Lib\s+\".*?\")', r'Declare PtrSafe \1', code, flags=re.IGNORECASE)
        updated = re.sub(r'As\s+Long(Ptr)?', r'As LongPtr', updated, flags=re.IGNORECASE)

        tlb_matches = re.findall(r'Lib\s+\"(.*?)\"', code)
        if tlb_matches:
            updated += "\n' [WARNING] These DLLs may not work in 64-bit Office:\n"
            for lib in set(tlb_matches):
                updated += f"'  - {lib} (manual validation required)\n"
            self.log_tlb_warning(filename, list(set(tlb_matches)))

        if 'CreateObject' in code or 'GetObject' in code:
            updated += "\n' [WARNING] Manual check recommended for ActiveX or COM object compatibility."

        return updated

    def convert(self):
        if not self.input_paths or not self.output_dir:
            messagebox.showwarning("Missing Info", "Please select macro files/folder and output folder.")
            return

        self.tlb_warnings = {}
        self.logs = []
        count = 0

        for path in self.input_paths:
            try:
                original = self.read_macro(path)
                converted = self.convert_code(original, os.path.basename(path))
                filename = os.path.basename(path)
                out_path = os.path.join(self.output_dir, filename)
                self.write_macro(converted, out_path)
                count += 1
                self.logs.append(f"Converted: {filename}")
            except Exception as e:
                error_msg = f"Error converting {path}: {str(e)}"
                self.logs.append(error_msg)
                messagebox.showerror("Error", error_msg)

        self.display_warnings()
        self.display_logs()
        messagebox.showinfo("Conversion Complete", f"Converted {count} macro(s). Check logs and warnings below.")

    def display_warnings(self):
        self.warning_text.delete("1.0", tk.END)
        if self.tlb_warnings:
            self.warning_text.insert(tk.END, "TLB/DLL Compatibility Warnings:\n\n")
            for file, libs in self.tlb_warnings.items():
                self.warning_text.insert(tk.END, f"{file}:\n")
                for lib in libs:
                    self.warning_text.insert(tk.END, f"  - {lib} (check for 64-bit compatibility)\n")
        else:
            self.warning_text.insert(tk.END, "No critical compatibility warnings found. You're good to go!")

    def display_logs(self):
        self.log_text.delete("1.0", tk.END)
        for log in self.logs:
            self.log_text.insert(tk.END, log + "\n")

if __name__ == "__main__":
    VBAMacroConverterGUI()
